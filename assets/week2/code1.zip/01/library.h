#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void welcome_user(char* name);
