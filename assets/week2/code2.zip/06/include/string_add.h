#include <string.h>

char* string_add(char* first, char* second);
