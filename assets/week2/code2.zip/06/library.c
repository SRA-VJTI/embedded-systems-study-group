#include "library.h"

void welcome_user(char* name)
{
    printf("Hello %s, we will learn about header files\n", name);
}