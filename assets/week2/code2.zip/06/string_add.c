#include "string_add.h"

char* string_add(char* first, char* second)
{
    return strcat(first, second);
}
