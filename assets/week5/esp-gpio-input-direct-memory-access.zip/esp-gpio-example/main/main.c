#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

void app_main(void)
{
    gpio_config_t io_conf;
    // bit mask for the pins, each bit maps to a GPIO 
    io_conf.pin_bit_mask = (1ULL<<0);

    // set gpio mode to input
    io_conf.mode = GPIO_MODE_INPUT;

    // enable pull up resistors
    io_conf.pull_up_en = 1;

    // disable pull down resistors
    io_conf.pull_down_en = 0;

    // disable gpio interrupts
    io_conf.intr_type = GPIO_INTR_DISABLE;

    // detailed description can be found at https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/gpio.html#_CPPv413gpio_config_t

    // configure gpio's according to the setting specified in the gpio struct
    esp_err_t err = gpio_config(&io_conf);

    // static volatile gpio_dev_t *__gpio_reg = (void*)0x3FF44000;
    static volatile uint32_t *gpio_in_arr = (void*)0x3FF4403C;
    
    while(1)
    {
        int bit_value = *gpio_in_arr & 0x1;
        
        ESP_LOGI("gpio","value: %d", bit_value);
        vTaskDelay(10/portTICK_PERIOD_MS);
    }
}
